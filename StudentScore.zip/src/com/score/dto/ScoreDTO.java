package com.score.dto;

public class ScoreDTO {
	private String stuName;
	private int korScore;
	private int engScore;
	private int mathScore;
	private int sciScore;
	private int socScore;
	
	
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public int getKorScore() {
		return korScore;
	}
	public void setKorScore(int korScore) {
		this.korScore = korScore;
	}
	public int getEngScore() {
		return engScore;
	}
	public void setEngScore(int engScore) {
		this.engScore = engScore;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	public int getSciScore() {
		return sciScore;
	}
	public void setSciScore(int sciScore) {
		this.sciScore = sciScore;
	}
	public int getSocScore() {
		return socScore;
	}
	public void setSocScore(int socScore) {
		this.socScore = socScore;
	}

	
	
}
